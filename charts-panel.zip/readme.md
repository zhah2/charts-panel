### Asset Allocation Research & Strategy Dashboard
Content included on the page:
* Charts: collecting all research charts and organize by topic; allow selection and download
* Targets: current and historical allocation targets, including: Cross Assets, Equity - Region, Equity - Sector, Bonds - Region, Bonds - Sector, FX, Commodities
* Backtest: allow putting in asset weights and see historical performance, and can see by regime performance
